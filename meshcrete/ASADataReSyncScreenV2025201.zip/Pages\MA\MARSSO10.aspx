<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="MARSSO10.aspx.cs" Inherits="Page_MARSSO10" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
  <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="ASADataReSyncScreen.ASADataReSyncProcess"
        PrimaryView="DetailsView"
        >
    <CallbackCommands>

    </CallbackCommands>
  </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
  <px:PXFormView Caption="" ID="form" runat="server" DataSourceID="ds" DataMember="Filter" Width="100%" Height="40px" AllowAutoHide="false">
    <Template>
      <px:PXLayoutRule runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
	<px:PXDateTimeEdit Text="Last Sync Date" ReadOnly="False" Enabled="True" CommitChanges="True" LabelText="Last Sync Date" runat="server" ID="CstPXDateTimeEdit10" DataField="LatestFullResyncAttempt_Date" ></px:PXDateTimeEdit>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule11" StartColumn="True" ></px:PXLayoutRule>
	<px:PXDateTimeEdit TimeMode="True" SuppressLabel="True" Text="Time" Enabled="True" ReadOnly="False" CommitChanges="True" runat="server" ID="CstPXDateTimeEdit12" DataField="LatestFullResyncAttempt_Time" LabelText="Time" ></px:PXDateTimeEdit></Template>
  </px:PXFormView></asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
  <px:PXSplitContainer runat="server" ID="exportSplit" SplitterPosition="500" Orientation="Vertical"
                         Height="100%" Width="100%" >
        <AutoSize Enabled="True" Container="Window" ></AutoSize>
        <Template1>
  <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="Details" AllowAutoHide="false">
    <Levels>
      <px:PXGridLevel DataMember="DetailsView">
          <Columns>
        <px:PXGridColumn DataField="Selected" Width="60" Type="CheckBox" ></px:PXGridColumn>
	<px:PXGridColumn DataField="CustomerOrdNbr" Width="280" ></px:PXGridColumn>
	<px:PXGridColumn DataField="Status" Width="280" />
	<px:PXGridColumn DataField="OrderNo" Width="280" />
	<px:PXGridColumn Label="Order Modifed Date" DataField="LatestFullResyncAttempt" Width="90" ></px:PXGridColumn>
	<px:PXGridColumn Label="Order Modified Time" Key="" DataField="LatestFullResyncAttempt_Time" Width="90" ></px:PXGridColumn></Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="100" ></AutoSize>
    <ActionBar >
    </ActionBar>
  </px:PXGrid></Template1>
    <Template2>
      <px:PXTab Height="100%" runat="server">
        <Items>
          <px:PXTabItem Text="Logs">
            <Template>
              <px:PXGrid runat="server" ID="grid2" Height="100%" SkinID="Details" Width="100%" AllowAutoHide="false" DataSourceID="ds">
                <AutoSize Container="Window" Enabled="True" MinHeight="100" ></AutoSize>
                <Levels>
                  <px:PXGridLevel DataMember="Logs">
                    <Columns>
                      <px:PXGridColumn DataField="OperationTime" DisplayFormat="g" Width="280" ></px:PXGridColumn>
                      <px:PXGridColumn DataField="OrderNo" Width="280" ></px:PXGridColumn>
	<px:PXGridColumn DataField="CustomerOrdNbr" Width="180" ></px:PXGridColumn>
                      <px:PXGridColumn DataField="Message" Width="280" ></px:PXGridColumn>
                      <px:PXGridColumn DataField="MessageType" Width="280" ></px:PXGridColumn>
                      <px:PXGridColumn DataField="ErrorCleared" Width="60" ></px:PXGridColumn>
	<px:PXGridColumn DataField="OrderModifiedTime_Date" Width="90" />
	<px:PXGridColumn DataField="OrderModifiedTime_Time" Width="90" /></Columns></px:PXGridLevel></Levels>
                <Mode AllowAddNew="False" ></Mode>
                <Mode AllowDelete="False" ></Mode>
                <Mode AllowFormEdit="False" ></Mode>
                <Mode AllowUpdate="False" ></Mode></px:PXGrid></Template></px:PXTabItem>
          <px:PXTabItem Text="Errors">
            <Template>
              <px:PXGrid runat="server" ID="gridErrorLogs" Height="100%" SkinID="Details" Width="100%" AllowAutoHide="false" DataSourceID="ds">
                <AutoSize Container="Window" Enabled="True" MinHeight="100" ></AutoSize>
                <Levels>
                  <px:PXGridLevel DataMember="ErrorLogs">
                    <Columns>
	<px:PXGridColumn CommitChanges="True" Type="CheckBox" DataField="Selected" Width="60" ></px:PXGridColumn>
                      <px:PXGridColumn DataField="OperationTime" DisplayFormat="g" Width="280" ></px:PXGridColumn>
                      <px:PXGridColumn DataField="OrderNo" Width="280" ></px:PXGridColumn>
	<px:PXGridColumn DataField="CustomerOrdNbr" Width="180" ></px:PXGridColumn>
                      <px:PXGridColumn DataField="Message" Width="280" ></px:PXGridColumn>
                      <px:PXGridColumn DataField="MessageType" Width="280" ></px:PXGridColumn></Columns>
                    <RowTemplate>
                      <px:PXButton runat="server" ID="CstButton6" ></px:PXButton></RowTemplate></px:PXGridLevel></Levels>
                <ActionBar>
                  <Actions>
                    <Save Enabled="True" ></Save></Actions></ActionBar>
                <Mode AllowDelete="True" AllowAddNew="False" AllowUpdate="True"  ></Mode>
                <Mode AllowDelete="True" ></Mode>
                <Mode AllowFormEdit="False" ></Mode>
                <Mode AllowUpdate="True" ></Mode></px:PXGrid></Template></px:PXTabItem></Items></px:PXTab></Template2>
    </px:PXSplitContainer></asp:Content>